#include <iostream>
#include <vector>

template <typename T1, typename T2>
class ordered_map
{
private:
    int treeSize;
    struct Node
    {
        T1 key;
        T2 value;
        Node *left;
        Node *right;
        int height;

        Node(T1 k, T2 v) : key(k), value(v), left(nullptr), right(nullptr), height(1) {}
    };

    Node *root;

    int getHeight(Node *node)
    {
        return (node ? node->height : 0);
    }

    int findBalance(Node *node)
    {
        return (node ? getHeight(node->left) - getHeight(node->right) : 0);
    }

    Node *rotateRight(Node *y)
    {
        Node *x = y->left;
        Node *temp = x->right;

        x->right = y;
        y->left = temp;

        y->height = std::max(getHeight(y->left), getHeight(y->right)) + 1;
        x->height = std::max(getHeight(x->left), getHeight(x->right)) + 1;

        return x;
    }

    Node *rotateLeft(Node *x)
    {
        Node *y = x->right;
        Node *temp = y->left;

        y->left = x;
        x->right = temp;

        x->height = std::max(getHeight(x->left), getHeight(x->right)) + 1;
        y->height = std::max(getHeight(y->left), getHeight(y->right)) + 1;

        return y;
    }

    Node *_insert(Node *node, T1 key, T2 value)
    {
        if (!node)
        {
            return new Node(key, value);
        }

        if (key < node->key)
        {
            node->left = _insert(node->left, key, value);
        }
        else if (key > node->key)
        {
            node->right = _insert(node->right, key, value);
        }
        else
        {
            node->value = value;
        }

        node->height = 1 + std::max(getHeight(node->left), getHeight(node->right));

        int balance = findBalance(node);

        if (balance > 1)
        {
            if (key < node->left->key)
            {
                return rotateRight(node);
            }
            else
            {
                node->left = rotateLeft(node->left);
                return rotateRight(node);
            }
        }

        if (balance < -1)
        {
            if (key > node->right->key)
            {
                return rotateLeft(node);
            }
            else
            {
                node->right = rotateRight(node->right);
                return rotateLeft(node);
            }
        }

        return node;
    }

    Node *findMin(Node *node)
    {
        while (node->left)
        {
            node = node->left;
        }
        return node;
    }

    Node *erase(Node *node, T1 key, bool &keyFound)
    {
        if (!node)
        {
            return nullptr;
        }

        if (key < node->key)
        {
            node->left = erase(node->left, key, keyFound);
        }
        else if (key > node->key)
        {
            node->right = erase(node->right, key, keyFound);
        }
        else
        {
            keyFound = true;

            if (!node->left || !node->right)
            {
                Node *temp = node->left ? node->left : node->right;
                if (!temp)
                {
                    temp = node;
                    node = nullptr;
                }
                else
                {
                    *node = *temp;
                }
                delete temp;
            }
            else
            {
                Node *temp = findMin(node->right);
                node->key = temp->key;
                node->value = temp->value;
                node->right = erase(node->right, temp->key, keyFound);
            }
        }

        if (!node)
        {
            return node;
        }

        node->height = 1 + std::max(getHeight(node->left), getHeight(node->right));

        int balance = findBalance(node);

        if (balance > 1)
        {
            if (findBalance(node->left) >= 0)
            {
                return rotateRight(node);
            }
            else
            {
                node->left = rotateLeft(node->left);
                return rotateRight(node);
            }
        }

        if (balance < -1)
        {
            if (findBalance(node->right) <= 0)
            {
                return rotateLeft(node);
            }
            else
            {
                node->right = rotateRight(node->right);
                return rotateLeft(node);
            }
        }

        return node;
    }

    void inorder(Node *node, std::vector<T1> &result)
    {
        if (!node)
            return;
        inorder(node->left, result);
        result.push_back(node->key);
        inorder(node->right, result);
    }

public:
    ordered_map() : root(nullptr), treeSize(0) {}

    void clear()
    {
        while (root)
        {
            erase(root->key);
        }
    }
    bool contains(T1 key)
    {
        Node *current = root;
        while (current)
        {
            if (key == current->key)
            {
                return true;
            }
            else if (key < current->key)
            {
                current = current->left;
            }
            else
            {
                current = current->right;
            }
        }
        return false;
    }

    bool insert(T1 key, T2 value)
    {
        Node *newNode = _insert(root, key, value);
        if (newNode)
        {
            root = newNode;
            treeSize++;
            return true;
        }
        return false;
    }

    bool erase(T1 key)
    {
        bool keyFound = false;
        root = erase(root, key, keyFound);
        if (keyFound)
        {
            treeSize--;
        }
        return keyFound;
    }
    std::vector<T1> keys()
    {
        std::vector<T1> result;
        inorder(root, result);
        return result;
    }
    int size() const
    {
        return treeSize;
    }

    T2 &operator[](T1 key)
    {
        Node *current = root;
        while (current)
        {
            if (key == current->key)
            {
                return current->value;
            }
            else if (key < current->key)
            {
                current = current->left;
            }
            else
            {
                current = current->right;
            }
        }
        Node *newNode = _insert(root, key, T2());
        root = newNode;
        return newNode->value;
    }

    bool empty()
    {
        return treeSize == 0;
    }
    std::pair<bool, T1> lower_bound(T1 key)
    {
        Node *current = root;
        Node *lb = nullptr;
        while (current)
        {
            if (key == current->key)
            {
                return std::make_pair(true, current->key);
            }
            else if (key < current->key)
            {
                lb = current;
                current = current->left;
            }
            else
            {
                current = current->right;
            }
        }
        return std::make_pair(false, lb ? lb->key : T1());
    }

    std::pair<bool, T1> upper_bound(T1 key)
    {
        Node *current = root;
        Node *ub = nullptr;

        while (current)
        {
            if (key < current->key)
            {
                ub = current;
                current = current->left;
            }
            else if (key > current->key)
            {
                current = current->right;
            }
            else
            {
                return std::make_pair(true, key);
            }
        }
        if (ub)
        {
            return std::make_pair(true, ub->key);
        }
        else
        {
            return std::make_pair(false, T1());
        }
    }
};

int main()
{
    ordered_map<std::string, std::string> omap;

    int choice;
    // std::cout << "Menu:\n";
    //     std::cout << "1. Check if the map is empty\n";
    //     std::cout << "2. Return size\n";
    //     std::cout << "3. Check if a key is present\n";
    //     std::cout << "4. Insert a key-value pair\n";
    //     std::cout << "5. Erase a key-value pair\n";
    //     std::cout << "6. Access a value using operator[]\n";
    //     std::cout << "7. Clear the map\n";
    //     std::cout << "8. Get keys in sorted order\n";
    //     std::cout << "9. Lower bound\n";
    //     std::cout << "10. Upper bound\n";
    //     std::cout << "0. Exit\n";
    //     std::cout << "Enter your choice: ";
    while (true)
    {
        std::cin >> choice;

        switch (choice)
        {
        case 1:
        {
            std::cout << (omap.empty() ? "true" : "false") << std::endl;
            break;
        }
        case 2:
        {
            std::cout << omap.size() << std::endl;
            break;
        }
        case 3:
        {
            std::string key;
            std::cin >> key;
            std::cout << (omap.contains(key) ? "true" : "false") << std::endl;
            break;
        }
        case 4:
        {
            std::string key;
            std::string value;
            std::cin >> key >> value;
            std::cout << (omap.insert(key, value) ? "true" : "false") << std::endl;
            break;
        }
        case 5:
        {
            std::string key;
            std::cin >> key;
            std::cout << (omap.erase(key) ? "true" : "false") << std::endl;
            break;
        }
        case 6:
        {
            std::string key;
            std::cin >> key;
            std::string &val = omap[key];
            std::cout << val << std::endl;
            break;
        }
        case 7:
            omap.clear();
            break;
        case 8:
        {
            std::vector<std::string> keys = omap.keys();
            for (const auto &key : keys)
            {
                std::cout << key << std::endl;
            }
            break;
        }
        case 9:
        {
            std::string key;
            std::cin >> key;
            auto result = omap.lower_bound(key);
            if (result.first)
            {
                std::cout << "true" << std::endl;
                std::cout << result.second << std::endl;
            }
            else
            {
                std::cout << "false" << std::endl;
            }
            break;
        }
        case 10:
        {
            std::string key;
            std::cin >> key;
            auto result = omap.upper_bound(key);
            if (result.first)
            {
                std::cout << "true" << std::endl;
                std::cout << result.second << std::endl;
            }
            else
            {
                std::cout << "false" << std::endl;
            }
            break;
        }
        default:
            std::cout << "Invalid choice. Please try again.\n";
        }
    }

    return 0;
}
